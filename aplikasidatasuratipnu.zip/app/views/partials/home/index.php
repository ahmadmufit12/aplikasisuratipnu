<?php 
$page_id = null;
$comp_model = new SharedController;
$current_page = $this->set_current_page_link();
?>
<div>
    <div  class="bg-light p-3 mb-3">
        <div class="container">
            <div class="row ">
                <div class="col-md-12 comp-grid">
                    <h4 >
                        <div><p align="center"><marquee> <font size="8" color="green" face="algerian"><u>Welcome To Aplikasi Data Surat PAC IPNU IPPNU</font></p></div></marquee></u>
                    <div><a <i class="fa fa-instagram" style="font-size:36px" color:red"  href="https://www.instagram.com/ipnuippnumayong/"></i><br></a></div></h4>
                </div>
                <div class="col-md-6 comp-grid">
                    <div class="">
                        <img src="assets/images/pac.jpg" width="470" height="320"/>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
