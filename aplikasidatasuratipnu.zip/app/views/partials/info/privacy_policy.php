<div class="container">
	<h4>Privacy Policy</h4>
	<hr />
	<div>
		Put page content here
	</div>
	<?php 
		if(DEVELOPMENT_MODE){ 
	?>
		<small class="text-muted">To edit this file, browse to :- <i>app/view/partials/info/privacy_policy.php</i></small>
	<?php 
		} 
	?>
	
</div>